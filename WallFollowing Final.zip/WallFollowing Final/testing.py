from stable_baselines3 import PPO    # Change to DQN, PPO or TD3
from continuous import *    # import discrete if you want to run discrete action space

"""
If you use DQN, you must import discrete action space.
If you use TD3, you must import continuous action space.

Change paths and model calls accordingly to your choice of model and action space.
"""

"""
Our best model is a fined-tuned PPO model that was trained on the X world (available in our world folder).
This code also allows to try another model, just change the model_path.
"""

def main():
    model_path = "best_model.zip"  # Verify
    custom_objects = {
        "lr_schedule": lambda : 0.001,
        "explorationschedule": lambda : 0.1
    }
    model = PPO.load(model_path, custom_objects=custom_objects)  # Verify

    env = WebotsWallFollowing()

    obs,_ = env.reset()
    done = False
    while not done:
        action, states = model.predict(obs, deterministic=True)
        obs, reward, done, _, info = env.step(action)
        env.render()

if __name__ == "__main__":
    main()